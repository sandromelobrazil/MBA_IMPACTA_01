# exercicio_dnsfootprint - 25 Agosto - 22h00
# exercicio_dnsfootprint
